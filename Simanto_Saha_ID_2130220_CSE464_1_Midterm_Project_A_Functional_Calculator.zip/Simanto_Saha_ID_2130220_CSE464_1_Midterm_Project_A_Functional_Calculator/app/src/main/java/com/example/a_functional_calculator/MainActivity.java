package com.example.a_functional_calculator;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Stack;

public class MainActivity extends AppCompatActivity {

    private TextView display;
    private StringBuilder input;
    private boolean isOpenBracket = true;
    private boolean isResultDisplayed = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        display = findViewById(R.id.display);
        input = new StringBuilder();


        setUpButtonListeners();
    }

    private void setUpButtonListeners() {

        findViewById(R.id.btn_0).setOnClickListener(v -> appendToInput("0"));
        findViewById(R.id.btn_1).setOnClickListener(v -> appendToInput("1"));
        findViewById(R.id.btn_2).setOnClickListener(v -> appendToInput("2"));
        findViewById(R.id.btn_3).setOnClickListener(v -> appendToInput("3"));
        findViewById(R.id.btn_4).setOnClickListener(v -> appendToInput("4"));
        findViewById(R.id.btn_5).setOnClickListener(v -> appendToInput("5"));
        findViewById(R.id.btn_6).setOnClickListener(v -> appendToInput("6"));
        findViewById(R.id.btn_7).setOnClickListener(v -> appendToInput("7"));
        findViewById(R.id.btn_8).setOnClickListener(v -> appendToInput("8"));
        findViewById(R.id.btn_9).setOnClickListener(v -> appendToInput("9"));
        findViewById(R.id.btn_dot).setOnClickListener(v -> appendToInput("."));


        findViewById(R.id.btn_add).setOnClickListener(v -> appendOperator("+"));
        findViewById(R.id.btn_subtract).setOnClickListener(v -> appendOperator("-"));
        findViewById(R.id.btn_multiply).setOnClickListener(v -> appendOperator("*"));
        findViewById(R.id.btn_divide).setOnClickListener(v -> appendOperator("/"));


        findViewById(R.id.btn_bracket).setOnClickListener(v -> toggleBracket());


        findViewById(R.id.btn_clear).setOnClickListener(v -> clearInput());
        findViewById(R.id.btn_del).setOnClickListener(v -> deleteLastCharacter());
        findViewById(R.id.btn_equal).setOnClickListener(v -> calculateResult());
    }

    private void appendToInput(String value) {
        if (isResultDisplayed) {

            input.setLength(0);
            isResultDisplayed = false;
        }
        input.append(value);
        display.setText(input.toString());
    }

    private void appendOperator(String operator) {
        if (isResultDisplayed) {

            isResultDisplayed = false;
        }
        input.append(operator);
        display.setText(input.toString());
    }

    private void toggleBracket() {
        if (isOpenBracket) {
            appendToInput("(");
        } else {
            appendToInput(")");
        }
        isOpenBracket = !isOpenBracket;
    }

    private void clearInput() {
        input.setLength(0);
        display.setText("0");
        isResultDisplayed = false;
    }

    private void deleteLastCharacter() {
        if (input.length() > 0) {
            input.deleteCharAt(input.length() - 1);
            display.setText(input.length() > 0 ? input.toString() : "0");
        }
    }

    private void calculateResult() {
        try {
            double result = evaluateExpression(input.toString());
            display.setText(String.valueOf(result));
            input.setLength(0);
            input.append(result);
            isResultDisplayed = true;
        } catch (Exception e) {
            display.setText("Error");
            input.setLength(0);
        }
    }

    private double evaluateExpression(String expression) throws Exception {
        Stack<Double> values = new Stack<>();
        Stack<Character> operators = new Stack<>();

        for (int i = 0; i < expression.length(); i++) {
            char c = expression.charAt(i);

            if (c == ' ')
                continue;


            if (c == '-' && (i == 0 || isOperator(expression.charAt(i - 1)) || expression.charAt(i - 1) == '(')) {
                StringBuilder sb = new StringBuilder();
                sb.append(c);
                i++;
                while (i < expression.length() && (Character.isDigit(expression.charAt(i)) || expression.charAt(i) == '.')) {
                    sb.append(expression.charAt(i++));
                }
                i--;
                values.push(Double.parseDouble(sb.toString()));
            }
            else if (Character.isDigit(c) || c == '.') {
                StringBuilder sb = new StringBuilder();
                while (i < expression.length() && (Character.isDigit(expression.charAt(i)) || expression.charAt(i) == '.')) {
                    sb.append(expression.charAt(i++));
                }
                i--;
                values.push(Double.parseDouble(sb.toString()));
            }
            else if (c == '(') {
                operators.push(c);
            }
            else if (c == ')') {
                while (!operators.isEmpty() && operators.peek() != '(') {
                    values.push(applyOp(operators.pop(), values.pop(), values.pop()));
                }
                operators.pop();
            }
            else if (isOperator(c)) {
                while (!operators.isEmpty() && hasPrecedence(c, operators.peek())) {
                    values.push(applyOp(operators.pop(), values.pop(), values.pop()));
                }
                operators.push(c);
            }
        }

        while (!operators.isEmpty()) {
            values.push(applyOp(operators.pop(), values.pop(), values.pop()));
        }

        return values.pop();
    }

    private boolean isOperator(char op) {
        return op == '+' || op == '-' || op == '*' || op == '/';
    }

    private boolean hasPrecedence(char op1, char op2) {
        if (op2 == '(' || op2 == ')')
            return false;
        if ((op1 == '*' || op1 == '/') && (op2 == '+' || op2 == '-'))
            return false;
        return true;
    }

    private double applyOp(char op, double b, double a) throws Exception {
        switch (op) {
            case '+': return a + b;
            case '-': return a - b;
            case '*': return a * b;
            case '/':
                if (b == 0) throw new ArithmeticException("Cannot divide by zero");
                return a / b;
        }
        return 0;
    }
}
